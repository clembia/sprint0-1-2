<?php

namespace app\controllers;

use Yii;
use yii\data\SqlDataProvider;


class AvanzamentoController extends \yii\web\Controller
{
    public function actionIndex()
    {
        $totale = Yii::$app->db->createCommand('select count(*) from exercisesvolto group by cfUtente')->queryScalar();
        if (Yii::$app->user->identity->role_id == 4){
            $cfUtAssociato=addslashes(Yii::$app->user->identity->cfUtAssociato);
            $query="select nome, cognome, dataNascita, cfUtente, count(*) as eserciziAssegnati, count(case svolto when 1 then 1 else null end) as eserciziSvolti from exercisesvolto join user on user.codFisc=exercisesvolto.cfUtente where cfUtente='$cfUtAssociato' group by cfUtente order by cognome, nome";
        }
        if (Yii::$app->user->identity->role_id == 3){
            $cfUtAssociato=addslashes(Yii::$app->user->identity->codFisc);
           $query="select nome, cognome, dataNascita, cfUtente, count(*) as eserciziAssegnati, count(case svolto when 1 then 1 else null end) as eserciziSvolti from exercisesvolto join user on user.codFisc=exercisesvolto.cfUtente where cfLogAssociato='$cfUtAssociato' group by cfUtente order by cognome, nome";
        }

    
        $dataProvider = new SqlDataProvider([
            'sql' => $query,
            'totalCount' => $totale,
            'sort' =>false,
            'pagination' => [
                'pageSize' => 10,
            ],
        ]);

      
        return $this->render('index', [
            'dataProvider' => $dataProvider,
             ]);
    }

}
