<?php
/* @var $this yii\web\View */

use yii\grid\GridView;


$this->title = 'Statistiche di avanzamento degli utenti';
if (Yii::$app->user->identity->role_id==3) 
    $this->params['breadcrumbs'][] = ['label' => 'Menù Logopedista', 'url' => ['site/homelogopedista']];
if (Yii::$app->user->identity->role_id==4) 
    $this->params['breadcrumbs'][] = ['label' => 'Menù Caregiver', 'url' => ['site/homecaregiver']];
$this->params['breadcrumbs'][] = $this->title;
?>

<h1>Statistiche di avanzamento degli utenti</h1>

<?= GridView::widget([
    'dataProvider' => $dataProvider,
    'columns' => [
        ['class' => 'yii\grid\SerialColumn'],
        [
            'label' =>"Cognome",
            'value'=>function($data){
                return $data["cognome"];
            }
        ],
        [
            'label' =>"Nome",
            'value'=>function($data){
                return $data["nome"];
            }
        ],
        [
            'label' =>"Codice Fiscale",
            'value'=>function($data){
                return $data["cfUtente"];
            }
        ],
        [
            'label' =>"nr. esercizi assegnati",
            'headerOptions' => ['width' => '180px'],
            'contentOptions' => ['style'=>'padding:0px 0px 0px 30px;vertical-align: middle;text-align:center'],
            'value'=>function($data){
                return $data["eserciziAssegnati"];
            }
        ],
        [
            'label' =>"nr. esercizi svolti",
            'headerOptions' => ['width' => '180px'],
            'contentOptions' => ['style'=>'padding:0px 0px 0px 30px;vertical-align: middle;text-align:center'],
            'value'=>function($data){
                return $data["eserciziSvolti"];
            
            }
        ],



    ],
]); ?>
