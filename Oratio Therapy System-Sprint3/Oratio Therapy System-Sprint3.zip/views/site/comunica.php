<?php

/** @var yii\web\View $this */

$this->title = 'Comunicazioni- Work in Progress';
use app\assets\CostruzioneAsset;
COstruzioneAsset::register($this);

?>
<br>
<section class="u-align-center u-clearfix u-custom-color-2 u-section-1" id="carousel_2ffc">
    <div class="u-clearfix u-sheet u-sheet-1" style="background-color: cornsilk">
        <h1 class="infinite u-custom-font u-font-montserrat u-text u-text-palette-2-dark-1 u-text-1" data-animation-name="pulse" data-animation-duration="1000" data-animation-direction="" data-animation-delay="0">IN COSTRUZIONE</h1>
        <img src="/css_a/images_a/60028-Converted.png" alt="" class="u-image u-image-contain u-image-default u-image-1" data-image-width="411" data-image-height="393">
        <p class="u-align-center u-text u-text-palette-2-base u-text-2"> La funzionalità richiesta non è al momento disponibile.&nbsp; <br>Ci scusiamo per l'inconveniente
        </p>
        <a href="/site/index" class="u-btn u-btn-round u-button-style u-hover-palette-1-light-1 u-palette-1-base u-radius-50 u-btn-1">TORNA ALl'HOMEPAGE</a>
      </div>
    </section>