<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use app\models\Exercisesvolto;

/* @var $this yii\web\View */
/* @var $searchModel app\models\AnomalieSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Verifica situazioni anomale';
$this->params['breadcrumbs'][] = ['label' => 'Menù Logopedista', 'url' => ['site/homelogopedista']];
$this->params['breadcrumbs'][] = 'Situazioni Anomale'
?>
<div class="user-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <h3 style="font-family: Verdana; color:red">Elenco utenti che non hanno effettuato esercizi da più di 3 giorni</h3>
    
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            //'role_id',
            //'status',
            'email:email',
           //'username',
            //'password',
            'cognome',
            'nome',
            //'dataNascita',
            [
                    'attribute' =>'codFisc',
                    'label' => 'Codice Fiscale',
            ],
            //'codFisc',
            //'cell',
            //'codLicenza',
            //'cfUtAssociato',
            //'cfLogAssociato',
            //'auth_key',
            //'access_token',
            //'logged_in_ip',
            [
            'label' =>'Nr. Esercizi anomali',
            'value' => function($model){
               return  Exercisesvolto::find()->select('Exercisesvolto.*')
                             ->where(['exercisesvolto.svolto'=>0, 'cfUtente'=>$model->codFisc] )
                             ->andwhere(['<=', 'exercisesvolto.dataAss', date("Y-m-d", strtotime("-3 days"))])->count();
            }
           ],
           
           // 'logged_in_at',
            //'created_ip',
            //'created_at',
            //'updated_at',
            //'banned_at',
            //'banned_reason',
            [
                'class' => ActionColumn::class,
                'template' =>'{view}',
                'buttons' => [
            
                    'view' => function ($url, $model, $key) {
           
                        return Html::a('&#128065', Url::toRoute(['utenti/view', 'id' => $model->id]), [

                            'title' => Yii::t('yii', 'View'), ]);
           
                    },
                ],

                'urlCreator' => function ($action,  $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
        ],
    ]); ?>


</div>
