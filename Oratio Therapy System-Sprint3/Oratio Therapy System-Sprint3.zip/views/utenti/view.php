<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Exercisesvolto;

/* @var $this yii\web\View */
/* @var $model amnah\yii2\user\models\User */

$this->title = 'Dettaglio accesso utente';
$this->params['breadcrumbs'][] = ['label' => 'Menù Logopedista', 'url' => ['site/homelogopedista']];
$this->params['breadcrumbs'][] = ['label' => 'Situazioni Anomale', 'url' => ['index']];
$this->params['breadcrumbs'][] = $model->cognome . ' ' .  $model->nome;
\yii\web\YiiAsset::register($this);
?>
<div class="user-view">

    <h1><?= Html::encode($this->title) ?></h1>

 

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            //'id',
            //'role_id',
            //'status',
            'email:email',
            'username',
            //'password',
            'cognome',
            'nome',
            'dataNascita:date',
            [
                'label' => 'Codice Fiscale Utente',
                'attribute' => 'codFisc',],
           // 'codFisc',
            //'cell',
            [
                'label' => 'Cellulare',
                'attribute' => 'cell',],
            //'codLicenza',
            //'cfUtAssociato',
            'cfLogAssociato',
            //'auth_key',
            //'access_token',
            //'logged_in_ip',
            'logged_in_at:datetime',
            [
                'label' =>'Nr. Esercizi anomali',
                'value' => function($model){
                   return  Exercisesvolto::find()->select('Exercisesvolto.*')
                                 ->where(['exercisesvolto.svolto'=>0, 'cfUtente'=>$model->codFisc] )
                                 ->andwhere(['<=', 'exercisesvolto.dataAss', date("Y-m-d", strtotime("-3 days"))])->count();
                }
            ],
            //'logged_in_at',
            //'created_ip',
            //'created_at',
            //'updated_at',
            //'banned_at',
            //'banned_reason',
        ],
    ]) ?>

</div>
