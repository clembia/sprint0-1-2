<?php

return [
    'adminEmail' => 'project.ingsoftware@gmail.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'da Contatti',
];
